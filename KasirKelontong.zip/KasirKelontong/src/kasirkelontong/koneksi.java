/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kasirkelontong;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

/**
 *
 * @author Zai
 */
public class koneksi {
    Connection con;
    public Connection getConnection(){
        try{
            con = DriverManager.getConnection("jdbc:mysql://localhost/kasirk","root","");
            //JOptionPane.showMessageDialog(null,"Koneksi berhasil");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,"Koneksi Error!");
        }
        return con;
    }
}


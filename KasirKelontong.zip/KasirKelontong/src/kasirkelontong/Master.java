/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kasirkelontong;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.KeyEvent;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.table.DefaultTableModel;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;


/**
 *
 * @author USER
 */


public class Master extends javax.swing.JFrame {

    /**
     * Creates new form Master
     */
    
    JasperReport Jasrep;
    JasperPrint Jaspri;
    Map param = new HashMap();
    JasperDesign JasDes;
    public Master() {
        initComponents();
        
        PanelTable.setEnabled(false);
        PanelTable.setVisible(false);
        PanelInput.setEnabled(false);
        PanelInput.setVisible(false);
        PanelAbout.setVisible(false);
        PanelAbout.setEnabled(false);
        PanelHapus.setVisible(false);
        PanelHapus.setEnabled(false);
        PanelTransaksi.setEnabled(false);
        PanelTransaksi.setVisible(false);
        Total.setEnabled(false);
        PanelETransaksi.setVisible(false);
        PanelETransaksi.setEnabled(false);
        Kembalian.setEnabled(false);
        infodefault();
        tablestyle();
        tampildagang();
        
    }
    
    DefaultTableModel uwu;
    DefaultTableModel ts;
    
    void tablestyle(){
        TabelBrg.getTableHeader().setOpaque(false);
        TabelBrg.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        TabelBrg.getTableHeader().setBackground(new Color(51, 51, 51));
        TabelBrg.getTableHeader().setForeground(new Color(255, 255, 255));
        TabelBrg.setRowHeight(25);
        TabelBrg.setDragEnabled(false);
        
    }
    
    void kembalian(){
        String ttl = Total.getText();
        String byr = Bayar.getText();
        
        int t = Integer.parseInt(ttl);
        int b = Integer.parseInt(byr);
        
        int kmb = b - t;
        String kembali = Integer.toString(kmb);
        
        Kembalian.setText(kembali);
    }
    
    void infodefault(){
        KategoriBrg.setEnabled(false);
        NamaBrg.setEnabled(false);
        HargaJual.setEnabled(false);
        HargaBeli.setEnabled(false);
    }
    
    void infochange(){
        KategoriBrg.setEnabled(true);
        NamaBrg.setEnabled(true);
        HargaJual.setEnabled(true);
        HargaBeli.setEnabled(true);
    }
    
    void tampiltransaksi(){
        String sql = "select transaksis.Kode_brg, transaksis.Nama_brg, dagangan.Per, transaksis.Jumlah, dagangan.Harga_Jual, transaksis.subtotal from transaksis inner join dagangan on dagangan.Kode_brg = transaksis.Kode_brg";
        String u = "Select SUM(subtotal) from transaksis";
        Object[]row={"Kode Barang","Nama Barang","Per","Jumlah Pembelian","Harga","Subtotal"};
        ts = new DefaultTableModel(null,row);
        TabelTransaksi.setModel(ts);
        try{
            Connection con = new koneksi().getConnection();
            Statement st = con.createStatement();
            ResultSet tampil = st.executeQuery(sql);
            while(tampil.next()){
                String Kode = tampil.getString("Kode_brg");
                String Nama = tampil.getString("Nama_brg");
                String per = tampil.getString("Per");
                String Jumlah = tampil.getString("Jumlah");
                String Harga = tampil.getString("Harga_Jual");
                String subtotal = tampil.getString("subtotal");
                Statement s = con.createStatement();
                ResultSet total = s.executeQuery(u);
                
                String data[]= {Kode, Nama, per, Jumlah, Harga, subtotal};
                ts.addRow(data);
                while(total.next()){
                String t = total.getString("SUM(subtotal)");
                Total.setText(t);    
                }
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Gagal Menampilkan data!");
        }
    }
    
    void infotransaksi(){
        try{
        int Row = TabelTransaksi.getSelectedRow();
        String kode = TabelTransaksi.getValueAt(Row, 0).toString();
        String nama = TabelTransaksi.getValueAt(Row, 1).toString();
        String Jumlah = TabelTransaksi.getValueAt(Row, 3).toString();
        
        KodeBrgT.setText(kode);
        NamaBrgT.setText(nama);
        JumlahBrgT.setText(Jumlah);
        
        PanelETransaksi.setVisible(true);
        PanelETransaksi.setEnabled(true);
        TabelTransaksi.getModel();
        TabelTransaksi.setEnabled(false);
        }catch(Exception e){
           JOptionPane.showMessageDialog(null,"Data gagal ditampilkan");
        }
    }
    
    void hapusT(){
        int konfirmasi = JOptionPane.showConfirmDialog(null, "Delete this data?","Confirmation",JOptionPane.YES_NO_OPTION);
        if(konfirmasi == 0){
            try{
                Connection c = new koneksi().getConnection();
                String sql = "Delete from transaksis where Kode_brg=?";
                PreparedStatement pr = c.prepareStatement(sql);
                pr.setString(1,KodeBrgT.getText());
                pr.executeUpdate();
                JOptionPane.showMessageDialog(null, "Deleted");
                PanelETransaksi.setVisible(false);
                PanelETransaksi.setEnabled(false);
                TabelTransaksi.setEnabled(true);
                tampiltransaksi();
            }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error");
        }
        }
    }
    
    void ctransaksi(){
        DateTimeFormatter waktu = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        
        ArrayList barang = new ArrayList();
        for(int i = 0; i<TabelTransaksi.getModel().getRowCount();i++){
            barang.add(TabelTransaksi.getModel().getValueAt(i, 1));
        }
        
        ArrayList jumlah = new ArrayList();
        for(int i = 0; i<TabelTransaksi.getModel().getRowCount();i++){
            jumlah.add(TabelTransaksi.getModel().getValueAt(i, 2));
        }
        
        try{
            Connection con = new koneksi().getConnection();
            String sql = "insert into transaksia(tgl_transaksi,barang,jumlah,total,bayar,kembalian) values('"+waktu.format(now)+"','"+barang+"','"+jumlah+"','"+Total.getText()+"','"+Bayar.getText()+"','"+Kembalian.getText()+"')";
            Statement s = con.createStatement();
            s.executeUpdate(sql);
            JOptionPane.showMessageDialog(null,"Success!!");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null,e.getMessage());
        }
        
    } 
    
    void tampildagang(){
        String sql = "select*from Dagangan";
        Object[]row={"Kode Barang","Nama Barang","Kategori","Satuan Jual","Harga Beli","Harga Jual"};
        uwu = new DefaultTableModel(null,row);
        TabelBrg.setModel(uwu);
        try{
            Connection con = new koneksi().getConnection();
            Statement st = con.createStatement();
            ResultSet tampil = st.executeQuery(sql);
            while(tampil.next()){
                String Kode = tampil.getString("Kode_brg");
                String Nama = tampil.getString("Nama_brg");
                String Kategori = tampil.getString("Kategori");
                String Per = tampil.getString("Per");
                String Hargab = tampil.getString("Harga_Beli");
                String Hargaj = tampil.getString("Harga_Jual");
                
                String data[]= {Kode, Nama, Kategori, Per, Hargab, Hargaj};
                uwu.addRow(data);
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Gagal Menampilkan data!");
        }
    }
    
    void transaksi(){
        int confirm = JOptionPane.showConfirmDialog(null,"Apakah ingin menambahkan ini ke transaksi?","Confirmation",JOptionPane.YES_NO_OPTION);
        if(confirm==0){
            try{
                Connection con = new koneksi().getConnection();
                String Kode = KodeBrg.getText();
                String Nama = NamaBrg.getText();
                String jumlah = JOptionPane.showInputDialog("Masukkan jumlah");
                HargaJual.getText();
                int hj = Integer.parseInt(HargaJual.getText());
                int sub = Integer.parseInt(jumlah)*hj;
                String sql = "insert into transaksis values('"+Kode+"','"+Nama+"','"+jumlah+"','"+sub+"')";
                Statement ins = con.createStatement();
                ins.executeUpdate(sql);
                JOptionPane.showMessageDialog(null, "Data Tersimpan");
            }catch(Exception e){
             JOptionPane.showMessageDialog(null, e.getMessage());
             
            }
        }
    }
    
    void a(){
         try{
            DateTimeFormatter waktu = DateTimeFormatter.ofPattern("yyy-MM-dd HH:mm:ss");
            LocalDateTime sekarang = LocalDateTime.now();
            Connection c = new koneksi().getConnection();
            
            String sl = "select transaksis.Kode_brg, transaksis.Nama_brg, dagangan.Per, transaksis.Jumlah, dagangan.Harga_Jual, transaksis.subtotal from transaksis inner join dagangan on dagangan.Kode_brg = transaksis.Kode_brg";
            Statement stm = c.createStatement();
            ResultSet r = stm.executeQuery(sl);
            while(r.next()){
                String Kode = r.getString("Kode_brg");
                String Nama = r.getString("Nama_brg");
                String Per = r.getString("Per");
                String Jumlah = r.getString("Jumlah");
                String Harga = r.getString("Harga_Jual");
                String Subtotal = r.getString("subtotal");
                String sql = "insert into transaksib(Kode_Barang, Nama_barang, Per, Jumlah, Harga, Subtotal) values('"+Kode+"','"+Nama+"','"+Per+"','"+Jumlah+"','"+Harga+"','"+Subtotal+"')";
                Statement s = c.createStatement();
                s.executeUpdate(sql);
            }
            
               
                String bd = "insert into transaksibd values ('"+waktu.format(sekarang)+"','"+nama.getText()+"','"+Total.getText()+"','"+Bayar.getText()+"','"+Kembalian.getText()+"')";
                Statement st = c.createStatement();
                st.executeUpdate(bd);
                JOptionPane.showMessageDialog(null, "Terimakasih");
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "error"+e.getMessage());
        }
    }
    
    /*void ctransaksii(){
        try{
            DateTimeFormatter waktu = DateTimeFormatter.ofPattern("yyy-MM-dd HH:mm:ss");
            LocalDateTime sekarang = LocalDateTime.now();
            Connection c = new koneksi().getConnection();
            
            int row = TabelTransaksi.getSelectedRow();
            String Kode = TabelTransaksi.getValueAt(row, 0).toString();
            String Nama = TabelTransaksi.getValueAt(row, 1).toString();
            String Per = TabelTransaksi.getValueAt(row, 2).toString();
            String Jumlah = TabelTransaksi.getValueAt(row ,3).toString();
            String Harga = TabelTransaksi.getValueAt(row, 4).toString();
            String Subtotal = TabelTransaksi.getValueAt(row ,5).toString();
            
                /*String sql = "insert into transaksib(Kode_Barang, Nama_barang, Per, Jumlah, Harga, Subtotal) values('"+Kode+"','"+Nama+"','"+Per+"','"+Jumlah+"','"+Harga+"','"+Subtotal+"')";
                Statement s = con.createStatement();
                s.executeUpdate(sql);
                String bd = "insert into transaksibd values ('"+waktu.format(sekarang)+"','"+nama.getText()+"','"+Total.getText()+"','"+Bayar.getText()+"','"+Kembalian.getText()+"')";
                Statement st = c.createStatement();
                st.executeUpdate(bd);
                JOptionPane.showMessageDialog(null, "Terimakasih");
        }catch(Exception e){
            
        }
    }*/
    void tampilnama(){
        try{
            String sql = "Select*from SUser";
            Connection con = new koneksi().getConnection();
            Statement st = con.createStatement();
            ResultSet tampil = st.executeQuery(sql);
            while(tampil.next()){
                String Nama = tampil.getString("Panggilan");
                nama.setText(Nama);
            }
            
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error");
        }
    }
    
    void caribarang(){
        String sql = "select*from Dagangan where Kode_brg like '%"+Searchbar.getText()+"%' or Nama_brg like '%"+Searchbar.getText()+"%'";
        Object[]row={"Kode Barang","Nama Barang","Kategori","Satuan Jual","Harga Beli","Harga Jual"};
        uwu = new DefaultTableModel(null,row);
        TabelBrg.setModel(uwu);
        try{
            Connection con = new koneksi().getConnection();
            Statement st = con.createStatement();
            ResultSet tampil = st.executeQuery(sql);
            while(tampil.next()){
                String Kode = tampil.getString("Kode_brg");
                String Nama = tampil.getString("Nama_brg");
                String Kategori = tampil.getString("Kategori");
                String Per = tampil.getString("Per");
                String Hargab = tampil.getString("Harga_Beli");
                String Hargaj = tampil.getString("Harga_Jual");
                
                String data[]= {Kode, Nama, Kategori, Per, Hargab, Hargaj};
                uwu.addRow(data);
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Gagal Menampilkan data!");
        }
    }
    
    void inputbarang(){
        if(InputKodeB.getText().trim().equals("")){
            JOptionPane.showMessageDialog(null,"Kode Kosong!");
            InputKodeB.requestFocus();
        }else if(InputNamaB.getText().trim().equals("")){
            JOptionPane.showMessageDialog(null,"Nama Kosong!");
            InputNamaB.requestFocus();
        }else if(InputPerB.getText().trim().equals("")){
            JOptionPane.showMessageDialog(null,"Per Kosong!");
            InputPerB.requestFocus();
        }else if(InputHargaBeliB.getText().trim().equals("")){
            JOptionPane.showMessageDialog(null,"Harga Beli Kosong!");
            InputHargaBeliB.requestFocus();
        }else if(InputHargaJualB.getText().trim().equals("")){
            JOptionPane.showMessageDialog(null,"Harga Jual Kosong!");
            InputHargaJualB.requestFocus();
        }else{
            try{
                Connection con = new koneksi().getConnection();
                String Kode = InputKodeB.getText();
                String Nama = InputNamaB.getText();
                String Per = InputPerB.getText();
                int Combobox = InputKategoriB.getSelectedIndex();
                String HargaB = InputHargaBeliB.getText();
                String HargaJ = InputHargaJualB.getText();
                String Kategori ="";
                
                switch (Combobox){
                    case 1 : 
                        Kategori = "Makanan";
                        break;
                    case 2 : 
                        Kategori = "Minuman";
                        break;
                    case 3 :
                        Kategori = "Obat";
                        break;
                    case 4 :
                        Kategori = "Mainan";
                        break;
                    case 5 :
                        Kategori = "Rokok";
                        break;
                    case 6 : 
                        Kategori = "Perlengkapan";
                        break;
                    case 7 :
                        Kategori = "Bahan Makanan";
                        break;
                    default :
                        Kategori = "";
                }
                
                String sql = "insert into dagangan values('"+Kode+"','"+Nama+"','"+Kategori+"','"+Per+"','"+HargaJ+"','"+HargaB+"')";
                Statement ins = con.createStatement();
                ins.executeUpdate(sql);
                JOptionPane.showMessageDialog(null, "Data Tersimpan");
                tampildagang();
            }catch(Exception e){
                JOptionPane.showMessageDialog(null,"Data Gagal Tersimpan");
            }
        }
    }
    
    void info(){
        try{
        int Row = TabelBrg.getSelectedRow();
        String kode = TabelBrg.getValueAt(Row, 0).toString();
        String nama = TabelBrg.getValueAt(Row, 1).toString();
        String kategori = TabelBrg.getValueAt(Row, 2).toString();
        String per = TabelBrg.getValueAt(Row, 3).toString();
        String HargaB = TabelBrg.getValueAt(Row, 4).toString();
        String HargaJ = TabelBrg.getValueAt(Row, 5).toString();
        
        KodeBrg.setText(kode);
        NamaBrg.setText(nama);
        
                
                switch (kategori){
                    case "Makanan" : 
                        KategoriBrg.setSelectedIndex(1);
                        break;
                    case "Minuman" : 
                        KategoriBrg.setSelectedIndex(2);
                        break;
                    case "Obat" :
                        KategoriBrg.setSelectedIndex(3);
                        break;
                    case "Mainan" :
                        KategoriBrg.setSelectedIndex(4);
                        break;
                    case "Rokok" :
                        KategoriBrg.setSelectedIndex(5);
                        break;
                    case "Perlengkapan" : 
                        KategoriBrg.setSelectedIndex(6);
                        break;
                    case "Bahan Makanan" :
                        KategoriBrg.setSelectedIndex(7);
                        break;
                    default :
                        KategoriBrg.setSelectedIndex(0);
                }
        
        SatuanBrg.setText(per);
        HargaBeli.setText(HargaB);
        HargaJual.setText(HargaJ);
        
        PanelHapus.setVisible(true);
        PanelHapus.setEnabled(true);
        TabelBrg.getModel();
        TabelBrg.setEnabled(false);
        }catch(Exception e){
           JOptionPane.showMessageDialog(null,"Data gagal ditampilkan");
        }
    }
    
    void infoupdate(){
        int updt = JOptionPane.showConfirmDialog(null, "Edit this data?","Confirmation",JOptionPane.YES_NO_OPTION);
        if(updt==0){
            try{
            Connection c = new koneksi().getConnection();
            String sql = "update dagangan set Nama_Brg=?, Kategori=?, Per=?, Harga_Jual=?, Harga_Beli=? where Kode_Brg='"+KodeBrg.getText()+"'";
            PreparedStatement p = c.prepareStatement(sql);
            String nama = NamaBrg.getText();
            int kategori = KategoriBrg.getSelectedIndex();
            String satuan = SatuanBrg.getText();
            String hj = HargaJual.getText();
            String hb = HargaBeli.getText();
            
            String ktgr="";
            
            switch (kategori){
                    case 1 : 
                        ktgr= "Makanan";
                        break;
                    case 2 : 
                        ktgr = "Minuman";
                        break;
                    case 3 :
                        ktgr = "Obat";
                        break;
                    case 4 :
                        ktgr = "Mainan";
                        break;
                    case 5 :
                        ktgr = "Rokok";
                        break;
                    case 6 : 
                        ktgr = "Perlengkapan";
                        break;
                    case 7 :
                        ktgr = "Bahan Makanan";
                        break;
                    default :
                        ktgr = "";
                }
            //p.setString(1, KodeBrg.getText());
            p.setString(1, nama);
            p.setString(2, ktgr);
            p.setString(3, satuan);
            p.setString(4, hj);
            p.setString(5, hb);
            
            p.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Update Sucess");
            tampildagang();
            infodefault();
            
            PanelHapus.setVisible(false);
            PanelHapus.setEnabled(false);
            TabelBrg.setEnabled(true);
            }catch(Exception e){
                JOptionPane.showMessageDialog(null, "ERROR!");
            }
        }
        
    }
    
    void hapus(){
        int konfirmasi = JOptionPane.showConfirmDialog(null, "Delete this data?","Confirmation",JOptionPane.YES_NO_OPTION);
        if(konfirmasi == 0){
            try{
                Connection c = new koneksi().getConnection();
                String sql = "Delete from dagangan where Kode_brg=?";
                PreparedStatement pr = c.prepareStatement(sql);
                pr.setString(1,KodeBrg.getText());
                pr.executeUpdate();
                JOptionPane.showMessageDialog(null, "Deleted");
                PanelHapus.setVisible(false);
                PanelHapus.setEnabled(false);
                TabelBrg.setEnabled(true);
                tampildagang();
            }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error");
        }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        halo = new javax.swing.JLabel();
        Sidebar = new javax.swing.JPanel();
        panelhome = new javax.swing.JPanel();
        Home = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        panelabout = new javax.swing.JPanel();
        Home1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        nama = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        TopBar = new javax.swing.JPanel();
        NamaToko = new javax.swing.JLabel();
        PanelTransaksi = new javax.swing.JPanel();
        PanelETransaksi = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        NamaBrgT = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        KodeBrgT = new javax.swing.JLabel();
        JumlahBrgT = new javax.swing.JLabel();
        Kembalian = new javax.swing.JTextField();
        Bayar = new javax.swing.JTextField();
        Total = new javax.swing.JTextField();
        jLabel34 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jButton11 = new javax.swing.JButton();
        Btransaksi = new javax.swing.JButton();
        Btransaksi1 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        TabelTransaksi = new javax.swing.JTable();
        Background3 = new javax.swing.JLabel();
        PanelTable = new javax.swing.JPanel();
        PanelHapus = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        HargaJual = new javax.swing.JTextField();
        NamaBrg = new javax.swing.JTextField();
        SatuanBrg = new javax.swing.JTextField();
        HargaBeli = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        KodeBrg = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        KategoriBrg = new javax.swing.JComboBox<>();
        jLabel22 = new javax.swing.JLabel();
        jButton10 = new javax.swing.JButton();
        Searchicon = new javax.swing.JLabel();
        Searchbar = new javax.swing.JTextField();
        Searchbaricon = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TabelBrg = new javax.swing.JTable();
        Background1 = new javax.swing.JLabel();
        PanelAbout = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        PanelHome = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        Input = new javax.swing.JLabel();
        LabelInput = new javax.swing.JLabel();
        ButtonInput = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        Tabel = new javax.swing.JLabel();
        LabelTabel = new javax.swing.JLabel();
        ButtonTabel = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        Transaksi = new javax.swing.JLabel();
        LabelTransaksi = new javax.swing.JLabel();
        ButtonTransaksi = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        Laporan = new javax.swing.JLabel();
        LabelLaporan = new javax.swing.JLabel();
        ButtonLaporan = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        About = new javax.swing.JLabel();
        LabelAbout = new javax.swing.JLabel();
        ButtonAbout = new javax.swing.JLabel();
        Background = new javax.swing.JLabel();
        PanelInput = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        InputHargaBeliB = new javax.swing.JTextField();
        InputKodeB = new javax.swing.JTextField();
        InputPerB = new javax.swing.JTextField();
        InputNamaB = new javax.swing.JTextField();
        InputHargaJualB = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        ButtonResetInput = new javax.swing.JLabel();
        ButtonSaveInput = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        InputKategoriB = new javax.swing.JComboBox<>();
        Background2 = new javax.swing.JLabel();

        jPanel1.setBackground(new java.awt.Color(102, 102, 102));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        halo.setFont(new java.awt.Font("LOVES", 1, 36)); // NOI18N
        halo.setForeground(new java.awt.Color(255, 204, 0));
        halo.setText("Coming Soon");
        jPanel1.add(halo, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 360, -1, -1));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);
        setSize(new java.awt.Dimension(1280, 720));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Sidebar.setBackground(new java.awt.Color(51, 51, 51));
        Sidebar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelhome.setBackground(new java.awt.Color(51, 51, 51));
        panelhome.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panelhomeMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                panelhomeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                panelhomeMouseExited(evt);
            }
        });

        Home.setFont(new java.awt.Font("Gotham Black", 0, 30)); // NOI18N
        Home.setForeground(new java.awt.Color(255, 255, 255));
        Home.setText("Home");

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/home.png"))); // NOI18N

        javax.swing.GroupLayout panelhomeLayout = new javax.swing.GroupLayout(panelhome);
        panelhome.setLayout(panelhomeLayout);
        panelhomeLayout.setHorizontalGroup(
            panelhomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelhomeLayout.createSequentialGroup()
                .addContainerGap(52, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(Home)
                .addGap(60, 60, 60))
        );
        panelhomeLayout.setVerticalGroup(
            panelhomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Home, javax.swing.GroupLayout.DEFAULT_SIZE, 93, Short.MAX_VALUE)
            .addGroup(panelhomeLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Sidebar.add(panelhome, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 340, 260, -1));

        panelabout.setBackground(new java.awt.Color(51, 51, 51));
        panelabout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panelaboutMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                panelaboutMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                panelaboutMouseExited(evt);
            }
        });

        Home1.setFont(new java.awt.Font("Gotham Black", 0, 30)); // NOI18N
        Home1.setForeground(new java.awt.Color(255, 255, 255));
        Home1.setText("Log Out");

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/logout.png"))); // NOI18N

        javax.swing.GroupLayout panelaboutLayout = new javax.swing.GroupLayout(panelabout);
        panelabout.setLayout(panelaboutLayout);
        panelaboutLayout.setHorizontalGroup(
            panelaboutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelaboutLayout.createSequentialGroup()
                .addContainerGap(54, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(Home1)
                .addGap(25, 25, 25))
        );
        panelaboutLayout.setVerticalGroup(
            panelaboutLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Home1, javax.swing.GroupLayout.DEFAULT_SIZE, 93, Short.MAX_VALUE)
            .addGroup(panelaboutLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel3)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        Sidebar.add(panelabout, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 430, 260, -1));

        nama.setBackground(new java.awt.Color(255, 255, 255));
        nama.setFont(new java.awt.Font("Gotham Black", 1, 24)); // NOI18N
        nama.setForeground(new java.awt.Color(255, 255, 255));
        nama.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        nama.setText("Nama");
        Sidebar.add(nama, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 190, 260, 50));

        jLabel35.setFont(new java.awt.Font("Gotham Black", 1, 24)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(255, 255, 255));
        jLabel35.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel35.setText("Happy Working");
        Sidebar.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, 260, 30));

        getContentPane().add(Sidebar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 260, 720));

        TopBar.setBackground(new java.awt.Color(255, 102, 102));

        NamaToko.setFont(new java.awt.Font("Gotham", 1, 36)); // NOI18N
        NamaToko.setForeground(new java.awt.Color(255, 255, 255));
        NamaToko.setText("Dalon Sejahtera");

        javax.swing.GroupLayout TopBarLayout = new javax.swing.GroupLayout(TopBar);
        TopBar.setLayout(TopBarLayout);
        TopBarLayout.setHorizontalGroup(
            TopBarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(TopBarLayout.createSequentialGroup()
                .addGap(371, 371, 371)
                .addComponent(NamaToko)
                .addContainerGap(370, Short.MAX_VALUE))
        );
        TopBarLayout.setVerticalGroup(
            TopBarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(NamaToko, javax.swing.GroupLayout.DEFAULT_SIZE, 75, Short.MAX_VALUE)
        );

        getContentPane().add(TopBar, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 0, 1030, 75));

        PanelTransaksi.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        PanelETransaksi.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel16.setBackground(new java.awt.Color(255, 51, 51));
        jPanel16.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel16.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel23.setFont(new java.awt.Font("Gotham Black", 0, 18)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setText("Info");
        jPanel16.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(204, -1, 40, 50));

        PanelETransaksi.add(jPanel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 430, 50));

        jButton6.setText("Delete");
        jButton6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton6MouseClicked(evt);
            }
        });
        PanelETransaksi.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 210, -1, -1));

        jButton7.setText("Close");
        jButton7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton7MouseClicked(evt);
            }
        });
        PanelETransaksi.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 210, -1, -1));

        NamaBrgT.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        NamaBrgT.setText("Nama Barang");
        PanelETransaksi.add(NamaBrgT, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 100, -1, -1));

        jLabel25.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel25.setText("Total");
        PanelETransaksi.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 130, -1, -1));

        jLabel29.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel29.setText("Name");
        PanelETransaksi.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 100, -1, -1));

        jLabel36.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel36.setText("Code");
        PanelETransaksi.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 70, -1, -1));

        KodeBrgT.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        KodeBrgT.setText("Kode Barang");
        PanelETransaksi.add(KodeBrgT, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 70, -1, -1));

        JumlahBrgT.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        JumlahBrgT.setText("Nama Barang");
        PanelETransaksi.add(JumlahBrgT, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 130, -1, -1));

        PanelTransaksi.add(PanelETransaksi, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 110, 430, 250));

        Kembalian.setFont(new java.awt.Font("Gotham Black", 0, 24)); // NOI18N
        Kembalian.setForeground(new java.awt.Color(255, 255, 255));
        PanelTransaksi.add(Kembalian, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 460, 220, -1));

        Bayar.setFont(new java.awt.Font("Caviar Dreams", 1, 24)); // NOI18N
        Bayar.setForeground(new java.awt.Color(255, 255, 255));
        Bayar.setBorder(null);
        Bayar.setOpaque(false);
        PanelTransaksi.add(Bayar, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 480, 190, -1));

        Total.setFont(new java.awt.Font("Caviar Dreams", 1, 24)); // NOI18N
        Total.setForeground(new java.awt.Color(255, 255, 255));
        Total.setBorder(null);
        Total.setOpaque(false);
        PanelTransaksi.add(Total, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 430, 190, -1));

        jLabel34.setFont(new java.awt.Font("Gotham Black", 0, 24)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(255, 255, 255));
        jLabel34.setText(": Rp.");
        PanelTransaksi.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 460, -1, -1));

        jLabel33.setFont(new java.awt.Font("Caviar Dreams", 1, 24)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(255, 255, 255));
        jLabel33.setText(": Rp.");
        PanelTransaksi.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 480, -1, -1));

        jLabel32.setFont(new java.awt.Font("Caviar Dreams", 1, 24)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(255, 255, 255));
        jLabel32.setText(": Rp.");
        PanelTransaksi.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 430, -1, -1));

        jLabel31.setFont(new java.awt.Font("Gotham Black", 0, 24)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(255, 255, 255));
        jLabel31.setText("Due");
        PanelTransaksi.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 460, -1, -1));

        jLabel30.setFont(new java.awt.Font("Caviar Dreams", 1, 24)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(255, 255, 255));
        jLabel30.setText("Paid");
        PanelTransaksi.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 480, -1, -1));

        jLabel1.setFont(new java.awt.Font("Caviar Dreams", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Total");
        PanelTransaksi.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 430, -1, -1));

        jButton11.setText("Total");
        jButton11.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton11MouseClicked(evt);
            }
        });
        PanelTransaksi.add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(107, 540, 240, -1));

        Btransaksi.setText("Transaction");
        Btransaksi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BtransaksiMouseClicked(evt);
            }
        });
        PanelTransaksi.add(Btransaksi, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 540, -1, -1));

        Btransaksi1.setText("Print Report");
        Btransaksi1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Btransaksi1MouseClicked(evt);
            }
        });
        PanelTransaksi.add(Btransaksi1, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 540, -1, -1));

        jScrollPane2.setBorder(null);

        TabelTransaksi.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        TabelTransaksi.setShowVerticalLines(false);
        TabelTransaksi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TabelTransaksiMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(TabelTransaksi);

        PanelTransaksi.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 50, 960, 320));

        Background3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/backgroundfinal.png"))); // NOI18N
        PanelTransaksi.add(Background3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 4, -1, -1));

        getContentPane().add(PanelTransaksi, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 1030, 650));

        PanelTable.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        PanelHapus.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel15.setBackground(new java.awt.Color(255, 51, 51));
        jPanel15.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel15.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel17.setFont(new java.awt.Font("Gotham Black", 0, 18)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Info");
        jPanel15.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(204, -1, 40, 50));

        PanelHapus.add(jPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 430, 50));

        jButton2.setText("Delete");
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });
        PanelHapus.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 340, -1, -1));

        jButton3.setText("Close");
        jButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton3MouseClicked(evt);
            }
        });
        PanelHapus.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 340, -1, -1));
        PanelHapus.add(HargaJual, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 250, 170, -1));
        PanelHapus.add(NamaBrg, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 130, 170, -1));
        PanelHapus.add(SatuanBrg, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 190, 170, -1));
        PanelHapus.add(HargaBeli, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 220, 170, -1));

        jLabel16.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel16.setText("Selling Price");
        PanelHapus.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 250, -1, -1));

        KodeBrg.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        KodeBrg.setText("Kode Barang");
        PanelHapus.add(KodeBrg, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 100, -1, -1));

        jLabel18.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel18.setText("Name");
        PanelHapus.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 130, -1, -1));

        jLabel19.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel19.setText("Category");
        PanelHapus.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 160, -1, -1));

        jLabel20.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel20.setText("Piece");
        PanelHapus.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 190, -1, -1));

        jLabel21.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel21.setText("Purchase Price");
        PanelHapus.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 220, -1, -1));

        jButton4.setText("Update");
        jButton4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton4MouseClicked(evt);
            }
        });
        PanelHapus.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 340, -1, -1));

        jButton5.setText("Change");
        jButton5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton5MouseClicked(evt);
            }
        });
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        PanelHapus.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 340, -1, -1));

        KategoriBrg.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih Kategori", "Makanan", "Minuman", "Obat", "Mainan", "Rokok", "Perlengkapan", "Bahan Masak" }));
        PanelHapus.add(KategoriBrg, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 160, 170, -1));

        jLabel22.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel22.setText("Code");
        PanelHapus.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 100, -1, -1));

        jButton10.setText("Transaction");
        jButton10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton10MouseClicked(evt);
            }
        });
        PanelHapus.add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 300, -1, -1));

        PanelTable.add(PanelHapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 70, 430, 420));

        Searchicon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/search icon.png"))); // NOI18N
        Searchicon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SearchiconMouseClicked(evt);
            }
        });
        PanelTable.add(Searchicon, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 50, -1, -1));

        Searchbar.setFont(new java.awt.Font("LOVES", 0, 16)); // NOI18N
        Searchbar.setForeground(new java.awt.Color(51, 51, 51));
        Searchbar.setBorder(null);
        Searchbar.setOpaque(false);
        Searchbar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                SearchbarKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                SearchbarKeyTyped(evt);
            }
        });
        PanelTable.add(Searchbar, new org.netbeans.lib.awtextra.AbsoluteConstraints(211, 50, 570, 50));

        Searchbaricon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/search bar.png"))); // NOI18N
        PanelTable.add(Searchbaricon, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 50, -1, -1));

        jScrollPane1.setBorder(null);

        TabelBrg.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        TabelBrg.setShowVerticalLines(false);
        TabelBrg.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TabelBrgMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TabelBrg);

        PanelTable.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 140, 960, 510));

        Background1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/backgroundfinal.png"))); // NOI18N
        PanelTable.add(Background1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 4, -1, -1));

        getContentPane().add(PanelTable, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 1030, 650));

        PanelAbout.setBackground(new java.awt.Color(51, 51, 51));
        PanelAbout.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel11.setFont(new java.awt.Font("Dovahkiin", 0, 36)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("zainuri");
        jLabel11.setToolTipText("");
        PanelAbout.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 160, -1, -1));

        jLabel14.setBackground(new java.awt.Color(255, 255, 255));
        jLabel14.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("ABOUT");
        PanelAbout.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 30, -1, -1));

        jLabel15.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Copyright @2019 Zainuri SWA");
        PanelAbout.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 380, -1, -1));

        jButton1.setText("Close");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });
        PanelAbout.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 370, -1, -1));

        getContentPane().add(PanelAbout, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 170, 580, 410));

        PanelHome.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setOpaque(false);
        jPanel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel4MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel4MouseExited(evt);
            }
        });
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Input.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/input.png"))); // NOI18N
        jPanel4.add(Input, new org.netbeans.lib.awtextra.AbsoluteConstraints(75, 0, -1, -1));

        LabelInput.setFont(new java.awt.Font("Gotham Black", 0, 14)); // NOI18N
        LabelInput.setForeground(new java.awt.Color(255, 255, 255));
        LabelInput.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LabelInput.setText("Input");
        jPanel4.add(LabelInput, new org.netbeans.lib.awtextra.AbsoluteConstraints(105, 120, -1, -1));

        ButtonInput.setFont(new java.awt.Font("Gotham", 1, 14)); // NOI18N
        ButtonInput.setForeground(new java.awt.Color(255, 255, 255));
        ButtonInput.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ButtonInput.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/selectmenu.png"))); // NOI18N
        ButtonInput.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ButtonInputMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ButtonInputMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ButtonInputMouseExited(evt);
            }
        });
        jPanel4.add(ButtonInput, new org.netbeans.lib.awtextra.AbsoluteConstraints(75, 150, -1, -1));

        PanelHome.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(404, 49, 250, 250));

        jPanel5.setOpaque(false);
        jPanel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel5MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel5MouseExited(evt);
            }
        });
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Tabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/Table.png"))); // NOI18N
        jPanel5.add(Tabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(75, 0, -1, -1));

        LabelTabel.setFont(new java.awt.Font("Gotham Black", 0, 14)); // NOI18N
        LabelTabel.setForeground(new java.awt.Color(255, 255, 255));
        LabelTabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LabelTabel.setText("Table");
        jPanel5.add(LabelTabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(105, 120, -1, -1));

        ButtonTabel.setFont(new java.awt.Font("Gotham", 1, 14)); // NOI18N
        ButtonTabel.setForeground(new java.awt.Color(255, 255, 255));
        ButtonTabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ButtonTabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/selectmenu.png"))); // NOI18N
        ButtonTabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ButtonTabelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ButtonTabelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ButtonTabelMouseExited(evt);
            }
        });
        jPanel5.add(ButtonTabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(75, 150, -1, -1));

        PanelHome.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(104, 49, 250, 250));

        jPanel6.setOpaque(false);
        jPanel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel6MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel6MouseExited(evt);
            }
        });
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Transaksi.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/transaksi.png"))); // NOI18N
        jPanel6.add(Transaksi, new org.netbeans.lib.awtextra.AbsoluteConstraints(75, 0, -1, -1));

        LabelTransaksi.setFont(new java.awt.Font("Gotham Black", 0, 14)); // NOI18N
        LabelTransaksi.setForeground(new java.awt.Color(255, 255, 255));
        LabelTransaksi.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LabelTransaksi.setText("Transaction");
        jPanel6.add(LabelTransaksi, new org.netbeans.lib.awtextra.AbsoluteConstraints(85, 120, -1, -1));

        ButtonTransaksi.setFont(new java.awt.Font("Gotham", 1, 14)); // NOI18N
        ButtonTransaksi.setForeground(new java.awt.Color(255, 255, 255));
        ButtonTransaksi.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ButtonTransaksi.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/selectmenu.png"))); // NOI18N
        ButtonTransaksi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ButtonTransaksiMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ButtonTransaksiMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ButtonTransaksiMouseExited(evt);
            }
        });
        jPanel6.add(ButtonTransaksi, new org.netbeans.lib.awtextra.AbsoluteConstraints(75, 150, -1, -1));

        PanelHome.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(704, 49, 250, 250));

        jPanel7.setOpaque(false);
        jPanel7.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel7MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel7MouseExited(evt);
            }
        });
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Laporan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/laporan.png"))); // NOI18N
        jPanel7.add(Laporan, new org.netbeans.lib.awtextra.AbsoluteConstraints(75, 0, -1, -1));

        LabelLaporan.setFont(new java.awt.Font("Gotham Black", 0, 14)); // NOI18N
        LabelLaporan.setForeground(new java.awt.Color(255, 255, 255));
        LabelLaporan.setText("Report");
        jPanel7.add(LabelLaporan, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 120, -1, -1));

        ButtonLaporan.setFont(new java.awt.Font("Gotham", 1, 14)); // NOI18N
        ButtonLaporan.setForeground(new java.awt.Color(255, 255, 255));
        ButtonLaporan.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ButtonLaporan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/selectmenu.png"))); // NOI18N
        ButtonLaporan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ButtonLaporanMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ButtonLaporanMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ButtonLaporanMouseExited(evt);
            }
        });
        jPanel7.add(ButtonLaporan, new org.netbeans.lib.awtextra.AbsoluteConstraints(75, 150, -1, -1));

        PanelHome.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 350, 250, 250));

        jPanel9.setOpaque(false);
        jPanel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jPanel9MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jPanel9MouseExited(evt);
            }
        });
        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        About.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/about.png"))); // NOI18N
        jPanel9.add(About, new org.netbeans.lib.awtextra.AbsoluteConstraints(75, 0, -1, -1));

        LabelAbout.setFont(new java.awt.Font("Gotham Black", 0, 14)); // NOI18N
        LabelAbout.setForeground(new java.awt.Color(255, 255, 255));
        LabelAbout.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LabelAbout.setText("About");
        jPanel9.add(LabelAbout, new org.netbeans.lib.awtextra.AbsoluteConstraints(105, 120, -1, -1));

        ButtonAbout.setFont(new java.awt.Font("Gotham", 1, 14)); // NOI18N
        ButtonAbout.setForeground(new java.awt.Color(255, 255, 255));
        ButtonAbout.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ButtonAbout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/selectmenu.png"))); // NOI18N
        ButtonAbout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ButtonAboutMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ButtonAboutMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ButtonAboutMouseExited(evt);
            }
        });
        jPanel9.add(ButtonAbout, new org.netbeans.lib.awtextra.AbsoluteConstraints(75, 150, -1, -1));

        PanelHome.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 350, 250, 250));

        Background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/backgroundfinal.png"))); // NOI18N
        PanelHome.add(Background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 2, -1, -1));

        getContentPane().add(PanelHome, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 1030, 650));

        PanelInput.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel10.setFont(new java.awt.Font("Gotham", 1, 36)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Input Barang");
        PanelInput.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 70, -1, -1));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        jLabel4.setText("Kode");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 60, -1, -1));

        jLabel5.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        jLabel5.setText("Per");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 170, -1, -1));

        jLabel6.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        jLabel6.setText("Harga Jual");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 280, -1, -1));

        jLabel7.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        jLabel7.setText("Nama Barang");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 60, -1, -1));

        jLabel8.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        jLabel8.setText("Kategori");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 170, -1, -1));

        jLabel9.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        jLabel9.setText("Harga Beli");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 280, -1, -1));

        InputHargaBeliB.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        InputHargaBeliB.setForeground(new java.awt.Color(255, 102, 102));
        InputHargaBeliB.setBorder(null);
        jPanel2.add(InputHargaBeliB, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 310, 230, -1));

        InputKodeB.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        InputKodeB.setForeground(new java.awt.Color(255, 102, 102));
        InputKodeB.setBorder(null);
        InputKodeB.setOpaque(false);
        jPanel2.add(InputKodeB, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 90, 230, -1));

        InputPerB.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        InputPerB.setForeground(new java.awt.Color(255, 102, 102));
        InputPerB.setBorder(null);
        InputPerB.setOpaque(false);
        jPanel2.add(InputPerB, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 200, 230, -1));

        InputNamaB.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        InputNamaB.setForeground(new java.awt.Color(255, 102, 102));
        InputNamaB.setBorder(null);
        jPanel2.add(InputNamaB, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 90, 230, -1));

        InputHargaJualB.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        InputHargaJualB.setForeground(new java.awt.Color(255, 102, 102));
        InputHargaJualB.setBorder(null);
        InputHargaJualB.setOpaque(false);
        jPanel2.add(InputHargaJualB, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 310, 230, -1));

        jLabel13.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("RESET");
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 440, -1, -1));

        jLabel12.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("SAVE");
        jPanel2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 440, -1, -1));

        ButtonResetInput.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/saveinput.png"))); // NOI18N
        ButtonResetInput.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ButtonResetInputMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ButtonResetInputMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ButtonResetInputMouseExited(evt);
            }
        });
        jPanel2.add(ButtonResetInput, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 430, -1, -1));

        ButtonSaveInput.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/saveinput.png"))); // NOI18N
        ButtonSaveInput.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ButtonSaveInputMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ButtonSaveInputMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ButtonSaveInputMouseExited(evt);
            }
        });
        jPanel2.add(ButtonSaveInput, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 430, -1, -1));

        jPanel12.setBackground(new java.awt.Color(51, 51, 51));

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 230, Short.MAX_VALUE)
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        jPanel2.add(jPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 332, 230, 5));

        jPanel10.setBackground(new java.awt.Color(51, 51, 51));

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 230, Short.MAX_VALUE)
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        jPanel2.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 112, 230, 5));

        jPanel3.setBackground(new java.awt.Color(51, 51, 51));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 230, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 112, 230, 5));

        jPanel14.setBackground(new java.awt.Color(51, 51, 51));

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 230, Short.MAX_VALUE)
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        jPanel2.add(jPanel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 332, 230, 5));

        jPanel13.setBackground(new java.awt.Color(51, 51, 51));

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 230, Short.MAX_VALUE)
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 5, Short.MAX_VALUE)
        );

        jPanel2.add(jPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 222, 230, 5));

        InputKategoriB.setFont(new java.awt.Font("Caviar Dreams", 1, 14)); // NOI18N
        InputKategoriB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pilih Kategori", "Makanan", "Minuman", "Obat", "Mainan", "Rokok", "Perlengkapan", "Bahan Masak" }));
        jPanel2.add(InputKategoriB, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 200, -1, -1));

        PanelInput.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 140, 960, 510));

        Background2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/backgroundfinal.png"))); // NOI18N
        PanelInput.add(Background2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 4, -1, -1));

        getContentPane().add(PanelInput, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 1030, 650));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void panelhomeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelhomeMouseEntered
    panelhome.setBackground(new Color(255,102,102));
    }//GEN-LAST:event_panelhomeMouseEntered

    private void panelhomeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelhomeMouseExited
     panelhome.setBackground(new Color(51,51,51));   // TODO add your handling code here:
    }//GEN-LAST:event_panelhomeMouseExited

    private void panelaboutMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelaboutMouseEntered
     panelabout.setBackground(new Color(255,102,102));   // TODO add your handling code here:
    }//GEN-LAST:event_panelaboutMouseEntered

    private void panelaboutMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelaboutMouseExited
      panelabout.setBackground(new Color(51,51,51));  // TODO add your handling code here:
    }//GEN-LAST:event_panelaboutMouseExited

    private void jPanel5MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel5MouseEntered
       
    }//GEN-LAST:event_jPanel5MouseEntered

    private void jPanel5MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel5MouseExited

    }//GEN-LAST:event_jPanel5MouseExited

    private void jPanel6MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel6MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel6MouseEntered

    private void jPanel6MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel6MouseExited
        //LabelTransaksi.setVisible(false);

        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel6MouseExited

    private void jPanel4MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel4MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel4MouseEntered

    private void jPanel4MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel4MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel4MouseExited

    private void jPanel9MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel9MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel9MouseEntered

    private void jPanel9MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel9MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel9MouseExited

    private void jPanel7MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel7MouseEntered
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel7MouseEntered

    private void jPanel7MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel7MouseExited
        // TODO add your handling code here:
    }//GEN-LAST:event_jPanel7MouseExited

    private void ButtonTabelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ButtonTabelMouseEntered
       ImageIcon ex = new ImageIcon(getClass().getResource("/icon/selectedmenu.png"));
      ButtonTabel.setIcon(ex); // TODO add your handling code here:
    }//GEN-LAST:event_ButtonTabelMouseEntered

    private void ButtonTabelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ButtonTabelMouseExited
      ImageIcon ex = new ImageIcon(getClass().getResource("/icon/selectmenu.png"));
      ButtonTabel.setIcon(ex);
    }//GEN-LAST:event_ButtonTabelMouseExited

    private void ButtonInputMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ButtonInputMouseEntered
        ImageIcon ex = new ImageIcon(getClass().getResource("/icon/selectedmenu.png"));
      ButtonInput.setIcon(ex);// TODO add your handling code here:
    }//GEN-LAST:event_ButtonInputMouseEntered

    private void ButtonInputMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ButtonInputMouseExited
      ImageIcon ex = new ImageIcon(getClass().getResource("/icon/selectmenu.png"));
      ButtonInput.setIcon(ex);  // TODO add your handling code here:
    }//GEN-LAST:event_ButtonInputMouseExited

    private void ButtonTransaksiMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ButtonTransaksiMouseEntered
      ImageIcon a = new ImageIcon(getClass().getResource("/icon/selectedmenu.png"));
      ButtonTransaksi.setIcon(a);// TODO add your handling code here:
    }//GEN-LAST:event_ButtonTransaksiMouseEntered

    private void ButtonTransaksiMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ButtonTransaksiMouseExited
      ImageIcon a = new ImageIcon(getClass().getResource("/icon/selectmenu.png"));
      ButtonTransaksi.setIcon(a);// TODO add your handling code here:
    }//GEN-LAST:event_ButtonTransaksiMouseExited

    private void ButtonAboutMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ButtonAboutMouseEntered
      ImageIcon a = new ImageIcon(getClass().getResource("/icon/selectedmenu.png"));
      ButtonAbout.setIcon(a);   // TODO add your handling code here:
    }//GEN-LAST:event_ButtonAboutMouseEntered

    private void ButtonAboutMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ButtonAboutMouseExited
      ImageIcon a = new ImageIcon(getClass().getResource("/icon/selectmenu.png"));
      ButtonAbout.setIcon(a);  // TODO add your handling code here:
    }//GEN-LAST:event_ButtonAboutMouseExited

    private void ButtonLaporanMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ButtonLaporanMouseEntered
      ImageIcon a = new ImageIcon(getClass().getResource("/icon/selectedmenu.png"));
      ButtonLaporan.setIcon(a);  // TODO add your handling code here:
    }//GEN-LAST:event_ButtonLaporanMouseEntered

    private void ButtonLaporanMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ButtonLaporanMouseExited
      ImageIcon a = new ImageIcon(getClass().getResource("/icon/selectmenu.png"));
      ButtonLaporan.setIcon(a);  // TODO add your handling code here:
    }//GEN-LAST:event_ButtonLaporanMouseExited

    private void panelhomeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelhomeMouseClicked
      PanelHome.setVisible(true);
      PanelHome.setEnabled(true);
      PanelTable.setVisible(false);
      PanelTable.setEnabled(false);
      PanelInput.setEnabled(false);
      PanelInput.setVisible(false);
      PanelTransaksi.setVisible(false);
      PanelTransaksi.setEnabled(false);
      // TODO add your handling code here:
    }//GEN-LAST:event_panelhomeMouseClicked

    private void ButtonTabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ButtonTabelMouseClicked
      PanelTable.setVisible(true);
      PanelTable.setEnabled(true);
      PanelHome.setVisible(false);
      PanelHome.setEnabled(false);
      PanelInput.setEnabled(false);
      PanelInput.setVisible(false);
      PanelTransaksi.setVisible(false);
      PanelTransaksi.setEnabled(false);
    }//GEN-LAST:event_ButtonTabelMouseClicked

    private void panelaboutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelaboutMouseClicked
       int out = JOptionPane.showConfirmDialog(null,"Are you sure?","Confirmation",JOptionPane.YES_NO_OPTION);
       if(out == 0){
       dispose();
       }else{
           JOptionPane.showMessageDialog(null, "Happy Working");
       }
    }//GEN-LAST:event_panelaboutMouseClicked

    private void SearchiconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SearchiconMouseClicked
      caribarang();  // TODO add your handling code here:
    }//GEN-LAST:event_SearchiconMouseClicked

    private void ButtonSaveInputMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ButtonSaveInputMouseEntered
      ImageIcon a = new ImageIcon(getClass().getResource("/icon/savedinput.png"));
      ButtonSaveInput.setIcon(a);// TODO add your handling code here:
    }//GEN-LAST:event_ButtonSaveInputMouseEntered

    private void ButtonSaveInputMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ButtonSaveInputMouseExited
      ImageIcon a = new ImageIcon(getClass().getResource("/icon/saveinput.png"));
      ButtonSaveInput.setIcon(a); // TODO add your handling code here:
    }//GEN-LAST:event_ButtonSaveInputMouseExited

    private void ButtonSaveInputMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ButtonSaveInputMouseClicked
       inputbarang(); // TODO add your handling code here:
    }//GEN-LAST:event_ButtonSaveInputMouseClicked

    private void ButtonResetInputMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ButtonResetInputMouseEntered
      ImageIcon a = new ImageIcon(getClass().getResource("/icon/savedinput.png"));
      ButtonResetInput.setIcon(a);  // TODO add your handling code here:
    }//GEN-LAST:event_ButtonResetInputMouseEntered

    private void ButtonResetInputMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ButtonResetInputMouseExited
      ImageIcon a = new ImageIcon(getClass().getResource("/icon/saveinput.png"));
      ButtonResetInput.setIcon(a);  // TODO add your handling code here:
    }//GEN-LAST:event_ButtonResetInputMouseExited

    private void ButtonResetInputMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ButtonResetInputMouseClicked
        InputKodeB.setText("");
        InputNamaB.setText("");
        InputPerB.setText("");
        InputKategoriB.setSelectedIndex(0);
        InputHargaBeliB.setText("");
        InputHargaJualB.setText("");// TODO add your handling code here:
    }//GEN-LAST:event_ButtonResetInputMouseClicked

    private void ButtonInputMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ButtonInputMouseClicked
      PanelTable.setVisible(false);
      PanelTable.setEnabled(false);
      PanelHome.setVisible(false);
      PanelHome.setEnabled(false);
      PanelInput.setEnabled(true);
      PanelInput.setVisible(true);
      PanelTransaksi.setVisible(false);
      PanelTransaksi.setEnabled(false);// TODO add your handling code here:
    }//GEN-LAST:event_ButtonInputMouseClicked

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
       PanelAbout.setVisible(false);
       PanelAbout.setEnabled(false);
    }//GEN-LAST:event_jButton1MouseClicked

    private void ButtonAboutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ButtonAboutMouseClicked
      PanelAbout.setVisible(true);
      PanelAbout.setEnabled(true); 
      // TODO add your handling code here:
    }//GEN-LAST:event_ButtonAboutMouseClicked

    private void jButton3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton3MouseClicked
      PanelHapus.setVisible(false);
      PanelHapus.setEnabled(false);
      TabelBrg.setEnabled(true);
      infodefault();
// TODO add your handling code here:
    }//GEN-LAST:event_jButton3MouseClicked

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked
       hapus(); // TODO add your handling code here:
    }//GEN-LAST:event_jButton2MouseClicked

    private void TabelBrgMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabelBrgMouseClicked
      info();  // TODO add your handling code here:
    }//GEN-LAST:event_TabelBrgMouseClicked

    private void jButton4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton4MouseClicked
      infoupdate();  // TODO add your handling code here:
    }//GEN-LAST:event_jButton4MouseClicked

    private void jButton5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton5MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5MouseClicked

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
     infochange();   // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton6MouseClicked
     hapusT();   // TODO add your handling code here:
    }//GEN-LAST:event_jButton6MouseClicked

    private void jButton7MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton7MouseClicked
       PanelETransaksi.setVisible(false);
      PanelETransaksi.setEnabled(false);
      TabelTransaksi.setEnabled(true);// TODO add your handling code here:
    }//GEN-LAST:event_jButton7MouseClicked

    private void TabelTransaksiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabelTransaksiMouseClicked
      infotransaksi();  // TODO add your handling code here:
    }//GEN-LAST:event_TabelTransaksiMouseClicked

    private void ButtonTransaksiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ButtonTransaksiMouseClicked
     PanelTable.setVisible(false);
      PanelTable.setEnabled(false);
      PanelHome.setVisible(false);
      PanelHome.setEnabled(false);
      PanelInput.setEnabled(false);
      PanelInput.setVisible(false);
      PanelTransaksi.setVisible(true);
      PanelTransaksi.setEnabled(true);  
      tampiltransaksi();
// TODO add your handling code here:
    }//GEN-LAST:event_ButtonTransaksiMouseClicked

    private void jButton10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton10MouseClicked
      transaksi();  // TODO add your handling code here:
    }//GEN-LAST:event_jButton10MouseClicked

    private void jButton11MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton11MouseClicked
      kembalian();  // TODO add your handling code here:
    }//GEN-LAST:event_jButton11MouseClicked

    private void SearchbarKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_SearchbarKeyPressed
     if(evt.getKeyCode()==KeyEvent.VK_ENTER){
     caribarang();
     }
     
    }//GEN-LAST:event_SearchbarKeyPressed

    private void SearchbarKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_SearchbarKeyTyped
      if("".equals(Searchbar.getText())){
          tampildagang();
      }
          // TODO add your handling code here:
    }//GEN-LAST:event_SearchbarKeyTyped

    private void BtransaksiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtransaksiMouseClicked
      ctransaksi();
      a();// TODO add your handling code here:
    }//GEN-LAST:event_BtransaksiMouseClicked

    private void Btransaksi1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_Btransaksi1MouseClicked

        /*String reportSource = null;
        String reportDest = null;
        
        try{
            Connection con = new koneksi().getConnection();
            reportSource = System.getProperty("user.dir") + "/src/kasirkelontong/report1.jrxml";
            reportDest = System.getProperty("user.dir")+ "/src/kasirkelontong/report1.jasper";
            
            JasperReport jasperReport = JasperCompileManager.compileReport(reportSource);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport,null,con);
            JasperExportManager.exportReportToHtmlFile(jasperPrint, reportDest);
            JasperViewer.viewReport(jasperPrint,false);
        } catch(Exception e){
            JOptionPane.showMessageDialog(null, e.getMessage());
        }*/
        
        try{
            koneksi objkoneksi = new koneksi();
            Connection con =objkoneksi.getConnection();
            String fileName="./src/kasirkelontong/report1.jrxml";
            String filetoFill="./src/kasirkelontong/report1.jasper";
            JasperCompileManager.compileReport(fileName);
            Map param= new HashMap();
            JasperFillManager.fillReport(filetoFill, param, con);
            JasperPrint jp=JasperFillManager.fillReport(filetoFill, param,con);
            JasperViewer.viewReport(jp,false);
 
        }catch(Exception ex){
               System.out.println(ex.toString());
        }
    }//GEN-LAST:event_Btransaksi1MouseClicked

    private void ButtonLaporanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ButtonLaporanMouseClicked
       try{
            koneksi objkoneksi = new koneksi();
            Connection con =objkoneksi.getConnection();
            String fileName="./src/kasirkelontong/report2.jrxml";
            String filetoFill="./src/kasirkelontong/report2.jasper";
            JasperCompileManager.compileReport(fileName);
            Map param= new HashMap();
            JasperFillManager.fillReport(filetoFill, param, con);
            JasperPrint jp=JasperFillManager.fillReport(filetoFill, param,con);
            JasperViewer.viewReport(jp,false);
 
        }catch(Exception ex){
               System.out.println(ex.toString());
        } // TODO add your handling code here:
    }//GEN-LAST:event_ButtonLaporanMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Master.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Master.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Master.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Master.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Master().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel About;
    private javax.swing.JLabel Background;
    private javax.swing.JLabel Background1;
    private javax.swing.JLabel Background2;
    private javax.swing.JLabel Background3;
    private javax.swing.JTextField Bayar;
    private javax.swing.JButton Btransaksi;
    private javax.swing.JButton Btransaksi1;
    private javax.swing.JLabel ButtonAbout;
    private javax.swing.JLabel ButtonInput;
    private javax.swing.JLabel ButtonLaporan;
    private javax.swing.JLabel ButtonResetInput;
    private javax.swing.JLabel ButtonSaveInput;
    private javax.swing.JLabel ButtonTabel;
    private javax.swing.JLabel ButtonTransaksi;
    private javax.swing.JTextField HargaBeli;
    private javax.swing.JTextField HargaJual;
    private javax.swing.JLabel Home;
    private javax.swing.JLabel Home1;
    private javax.swing.JLabel Input;
    private javax.swing.JTextField InputHargaBeliB;
    private javax.swing.JTextField InputHargaJualB;
    private javax.swing.JComboBox<String> InputKategoriB;
    private javax.swing.JTextField InputKodeB;
    private javax.swing.JTextField InputNamaB;
    private javax.swing.JTextField InputPerB;
    private javax.swing.JLabel JumlahBrgT;
    private javax.swing.JComboBox<String> KategoriBrg;
    private javax.swing.JTextField Kembalian;
    private javax.swing.JLabel KodeBrg;
    private javax.swing.JLabel KodeBrgT;
    private javax.swing.JLabel LabelAbout;
    private javax.swing.JLabel LabelInput;
    private javax.swing.JLabel LabelLaporan;
    private javax.swing.JLabel LabelTabel;
    private javax.swing.JLabel LabelTransaksi;
    private javax.swing.JLabel Laporan;
    private javax.swing.JTextField NamaBrg;
    private javax.swing.JLabel NamaBrgT;
    private javax.swing.JLabel NamaToko;
    private javax.swing.JPanel PanelAbout;
    private javax.swing.JPanel PanelETransaksi;
    private javax.swing.JPanel PanelHapus;
    private javax.swing.JPanel PanelHome;
    private javax.swing.JPanel PanelInput;
    private javax.swing.JPanel PanelTable;
    private javax.swing.JPanel PanelTransaksi;
    private javax.swing.JTextField SatuanBrg;
    private javax.swing.JTextField Searchbar;
    private javax.swing.JLabel Searchbaricon;
    private javax.swing.JLabel Searchicon;
    private javax.swing.JPanel Sidebar;
    private javax.swing.JLabel Tabel;
    private javax.swing.JTable TabelBrg;
    private javax.swing.JTable TabelTransaksi;
    private javax.swing.JPanel TopBar;
    private javax.swing.JTextField Total;
    private javax.swing.JLabel Transaksi;
    private javax.swing.JLabel halo;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    protected javax.swing.JLabel nama;
    private javax.swing.JPanel panelabout;
    private javax.swing.JPanel panelhome;
    // End of variables declaration//GEN-END:variables
}


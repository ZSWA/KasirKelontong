-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 09 Bulan Mei 2019 pada 02.55
-- Versi server: 10.1.34-MariaDB
-- Versi PHP: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restor`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `entrimenu`
--

CREATE TABLE `entrimenu` (
  `Id` varchar(10) NOT NULL,
  `Namamakanan` varchar(20) NOT NULL,
  `Harga` int(20) NOT NULL,
  `Status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `entrimenu`
--

INSERT INTO `entrimenu` (`Id`, `Namamakanan`, `Harga`, `Status`) VALUES
('4636', 'ayam goreng', 12000, 'Tersedia'),
('1111', 'bakso', 10000, 'Tersedia'),
('0001', 'pizza', 100000, 'Tersedia'),
('112', 'nasgor', 5000, 'Tersedia'),
('23', 'bakso bakar', 5000, 'Tersedia');

-- --------------------------------------------------------

--
-- Struktur dari tabel `entriorder`
--

CREATE TABLE `entriorder` (
  `Id_order` int(10) NOT NULL,
  `Order` varchar(20) NOT NULL,
  `Harga` int(20) NOT NULL,
  `Jumlah` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `entriorder`
--

INSERT INTO `entriorder` (`Id_order`, `Order`, `Harga`, `Jumlah`) VALUES
(1, '4636', 10000, 2),
(2, '4636', 10000, 2),
(3, '4636', 10000, 10),
(4, '0001', 100000, 2),
(5, '4636', 12000, 1),
(6, '112', 5000, 1),
(7, '23', 5000, 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `login`
--

CREATE TABLE `login` (
  `Id` int(10) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(25) NOT NULL,
  `Usertype` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `login`
--

INSERT INTO `login` (`Id`, `Username`, `Password`, `Usertype`) VALUES
(1, 'fandi', '1234', 'Admin'),
(10, 'andik', '10000', 'Waiter'),
(11111, 'stark', '5678', 'Waiter');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi`
--

CREATE TABLE `transaksi` (
  `Id_transaksi` int(10) NOT NULL,
  `Namatrans` varchar(20) NOT NULL,
  `Hargatrans` int(20) NOT NULL,
  `Jumlahtrans` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `transaksi`
--

INSERT INTO `transaksi` (`Id_transaksi`, `Namatrans`, `Hargatrans`, `Jumlahtrans`) VALUES
(1, 'ayam goreng', 10000, 2),
(2, 'bakso', 10000, 10),
(3, 'ayam goreng', 10000, 10),
(4, 'ayam goreng', 10000, 3),
(5, 'ayam goreng', 10000, 2),
(6, 'ayam goreng', 10000, 10),
(7, 'bakso', 10000, 4),
(8, 'bakso bakar', 5000, 2);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
